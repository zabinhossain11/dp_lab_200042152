﻿using _200042152_lab06;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _200042152_lab06
{







    internal class Program
    {
        static void Main(string[] args)
        {
            PostalNotify postalNotify = new PostalNotify();

            PostalNotifyAdapter postalNotifyAdapter= new PostalNotifyAdapter(postalNotify,120,"dhaka");

            postalNotifyAdapter.sendNotification("Notification via postal mail");

            SMS sms = new SMS();

            sms.sendNotification("Notification via SMS");
            


            Console.ReadKey();

            


        }
    }

}

