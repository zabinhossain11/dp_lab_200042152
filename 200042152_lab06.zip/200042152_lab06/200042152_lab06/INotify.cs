﻿namespace _200042152_lab06
{
    public interface INotify
    {
        void sendNotification(string msg);

    }

}

