﻿using System;

namespace _200042152_lab06
{
    public class SMS : INotify
    {
        public SMS() { }
        public void sendNotification(string msg) { Console.WriteLine(msg); }
    }

}

