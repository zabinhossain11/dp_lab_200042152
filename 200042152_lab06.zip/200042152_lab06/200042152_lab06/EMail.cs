﻿using System;

namespace _200042152_lab06
{
    public class EMail : INotify
    {
        public EMail() { }
        public void sendNotification(string msg) { Console.WriteLine(msg); }
    }

}

