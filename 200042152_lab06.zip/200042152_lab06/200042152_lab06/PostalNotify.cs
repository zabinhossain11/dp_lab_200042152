﻿using System;

namespace _200042152_lab06
{
    public class PostalNotify
    { public PostalNotify() { }

      
    
      public void sendNotification(string msg, double code, string area)
        {
            Console.WriteLine($"{msg} {code} {area}");

        }
      
    
    }

}

