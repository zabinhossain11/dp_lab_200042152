﻿namespace _200042152_lab06
{
    public class PostalNotifyAdapter : INotify
    {
        private double code;
        private string area;

        private PostalNotify postalNotify;
        public PostalNotifyAdapter(PostalNotify postalNotify, double code, string area)

        {

            this.postalNotify = postalNotify;
            this.code = code;
            this.area = area;    

        }

        public void sendNotification(string msg)

        {
            postalNotify.sendNotification(msg, code, area);

        }



    }

}

