﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Designpattern
{
    public class Admin
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Role { get; set; }

        public Admin(int id, string name, string role)
        {
            Id = id;
            Name = name;
            Role = role;
        }

        public void ManageDriver(Driver driver)
        {
            // Logic to manage driver (e.g., deactivate, review rating)
        }

        public void ManageRider(Rider rider)
        {
            // Logic to manage rider (e.g., ban, review rating)
        }

        public void ViewTripHistory(List<Trip> trips)
        {
            // Logic to view trip history
            foreach (var trip in trips)
            {
                Console.WriteLine($"Trip from {trip.PickupLocation} to {trip.DropOffLocation} - Status: {trip.Status}");
            }
        }

        public void HandleDispute(Trip trip)
        {
            // Logic to handle disputes
        }
    }

}
