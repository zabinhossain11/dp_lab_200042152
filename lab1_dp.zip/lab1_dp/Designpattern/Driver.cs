﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Designpattern
{
    public class Driver : User
    {
        public string VehicleType { get; set; }
        public bool IsAvailable { get; set; }

        public Driver(int id, string name, string location, string vehicleType)
            : base(id, name, location)
        {
            VehicleType = vehicleType;
            IsAvailable = true;
        }

        public void AcceptRide(Trip trip)
        {
            IsAvailable = false;
           
        }

        public void StartTrip(Trip trip)
        {
           
        }

        public void CompleteTrip(Trip trip)
        {
            IsAvailable = true;
           
        }

        public void RateRider(Rider rider, decimal rating)
        {
            rider.Rating = (rider.Rating + rating) / 2;
        }
    }

}
