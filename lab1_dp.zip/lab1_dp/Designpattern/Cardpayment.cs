﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Designpattern
{
    public class Cardpayment: IPayment
    {
      

        public void ProcessPayment(decimal amount)
        {
            Console.WriteLine($"Processing card payment of {amount:C}");
        }
    }
}
