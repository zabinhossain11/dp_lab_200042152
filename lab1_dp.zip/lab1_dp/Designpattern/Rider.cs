﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Designpattern
{
    public class Rider : User
    {
        public IPayment PreferredPayment { get; set; }

        public Rider(int id, string name, string location, IPayment paymentMethod)
            : base(id, name, location)
        {
            PreferredPayment = paymentMethod;
        }

        public void RequestRide(string pickupLocation, string dropOffLocation, IRideType rideType)
        {

        }

        public void RateDriver(Driver driver, decimal rating)
        {
            
        }

        public void MakePayment(decimal amount)
        {
           
        }
    }

}
