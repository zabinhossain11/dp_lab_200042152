﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Designpattern
{

    public interface IRideType
    {
        decimal CalculateFare(decimal distance);
        string RideTypeName { get; }
    }

    public class CarpoolRide : IRideType
    {
        public string RideTypeName => "Carpool";

        public decimal CalculateFare(decimal distance)
        {
            decimal baseFare = 10.0m;
            decimal perKmRate = 2.0m;

    
            return baseFare + (perKmRate * distance) / 2; 
        }
    }


    public class LuxuryRide : IRideType
    {
        public string RideTypeName => "LuxuryRide";

        public decimal CalculateFare(decimal distance)
        {
            decimal baseFare = 50.0m;
            decimal perKmRate = 5.0m;

         
            return baseFare + (perKmRate * distance);
        }
    }


    public class BikeRide : IRideType
    {
        public string RideTypeName => "BikeRide";

        public decimal CalculateFare(decimal distance)
        {
            decimal baseFare = 5.0m;
            decimal perKmRate = 1.0m;

            
            return baseFare + (perKmRate * distance);
        }
    }

    public class Trip
    {
        public int Id { get; set; }
        public string PickupLocation { get; set; }
        public string DropOffLocation { get; set; }
        public IRideType RideType { get; set; }
        public decimal Fare { get; set; }
        public Driver AssignedDriver { get; set; }
        public Rider AssignedRider { get; set; }
        public string Status { get; set; }
        public decimal Distance { get; set; }

        public Trip(Rider rider, Driver driver, string pickupLocation, string dropOffLocation, IRideType rideType, decimal distance)
        {
            AssignedRider = rider;
            AssignedDriver = driver;
            PickupLocation = pickupLocation;
            DropOffLocation = dropOffLocation;
            RideType = rideType;
            Distance = distance;
            Status = "Pending";
            Fare = RideType.CalculateFare(Distance);
        }


        public void StartTrip()
        {


        }



        public void CompleteTrip()
        {
           
        }
    }




}
